https://www.praneetmathur.me
https://blog.praneetmathur.me/fractals/

Made from scratch by Praneet Mathur
Source code snippets available from download page
Made using Microsoft Visual Studio 2017, Rhino and Grasshopper SDK v6
Tested only on Rhino 6 BETA and the in-built Grasshopper plugin
Use at your own risk
This plugin is downloadable for FREE
For more information contact:
contact@praneetmathur.me
9958878946

Installation steps:

Step 1: Extract all files to a folder on your Desktop.
Step 2: Open Rhinoceros and run Grasshopper.
Step 3: Click on File > Special Folders > Components Folder .
Step 4: Copy "Fractals.gha", "Fractals.pdb" and "Fractals.xml" from extraxted folder on your desktop.
Step 5: Paste these files in the Components Folder (usually named "Libraries").
Step 6: Close everything and restart Rhino, run Grasshopper. The plugin tab "Fractals" should appear with 3 components.

For a better understanding of how these components work, visit:
https://www.codeproject.com/Articles/650821/Fractals-in-theory-and-practice

More Components coming soon!

Thank you!